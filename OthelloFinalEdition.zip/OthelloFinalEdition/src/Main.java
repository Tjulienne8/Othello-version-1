import view.OthelloView;
import processing.core.PApplet;

public class Main extends OthelloView {

    public static void main(String[] args) {
        PApplet.main(OthelloView.class);
    }
}